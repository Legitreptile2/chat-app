# Handles user login and registration
