# Database models for users and messages
