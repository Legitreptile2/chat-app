# Sets up and initializes the database
