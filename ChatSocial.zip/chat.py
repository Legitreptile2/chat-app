# Handles chat routes and SocketIO events
